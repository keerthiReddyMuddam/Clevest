﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClevestCodingTest
{
    class SignalFinder
    {
        Dictionary<string, int> directSignals = new Dictionary<string, int>();
        Dictionary<string, string> signalsTodecoded = new Dictionary<string, string>();
        Dictionary<string, string> Operators = new Dictionary<string, string>() {
                { "AND", "&" },
                { "OR", "|" },
                { "NOT", "~" },
                { "LSHIFT", "<<" },
                { "RSHIFT", ">>" }
            };
        bool isFirstitteration = true;
        List<string> DeleteKeys = new List<string>();
        StringBuilder outputString = new StringBuilder();

        public void GetSignalDetails()
        {
            Console.WriteLine("Please enter the file path \n");
            string filePath = Console.ReadLine();
            string[] Instructions = System.IO.File.ReadAllLines(filePath);
            try
            {
                foreach (string Instruction in Instructions)
                {
                    string key = Instruction.Split(new string[] { "->" }, StringSplitOptions.None)[1].Trim();
                    string Value = Instruction.Split(new string[] { "->" }, StringSplitOptions.None)[0].Trim();
                    if (Value.All(Char.IsDigit))
                    {
                        directSignals.Add(key, Convert.ToInt32(Value));
                        outputString.Append(key + " : " + Value + "\n");
                    }
                    else
                    {
                        DecodeSignals(key, Value);
                    }
                }

                while (!(signalsTodecoded.Count == 0))
                {
                    isFirstitteration = false;
                    foreach (KeyValuePair<string, string> valuepair in signalsTodecoded)
                        DecodeSignals(valuepair.Key, valuepair.Value);
                    foreach (string item in DeleteKeys)
                    {
                        signalsTodecoded.Remove(item);
                    }
                    DeleteKeys.Clear();
                }
                Console.WriteLine(outputString.ToString());
            }
            catch (Exception ex)
            { Console.WriteLine("Error :" + ex.Message); }
        }

        public void DecodeSignals(string key, string Value)
        {

            bool flag = true;
            string[] sarray = Value.Split(' ');

            for (int i = 0; i <= sarray.Length - 1; i++)
            {
                if (!(Operators.Keys.Contains(sarray[i]) || directSignals.Keys.Contains(sarray[i]) || sarray[i].All(char.IsDigit)))
                {
                    flag = false;
                    break;
                }
                else
                {
                    if (directSignals.Keys.Contains(sarray[i]))
                    {
                        sarray[Array.IndexOf(sarray, sarray[i])] = directSignals[sarray[i]].ToString();
                    }
                }
                if (i == sarray.Length - 1 && flag == true)
                {
                    int op1, op2, result = 0;
                    if (sarray.Count() == 3)
                    {
                        int.TryParse(sarray[0], out op1);
                        int.TryParse(sarray[2], out op2);
                        result = ComputeExp(op1, sarray[1], op2);
                    }
                    else if (sarray.Count() == 2)
                    {
                        op1 = 0;
                        int.TryParse(sarray[1], out op2);
                        result = ComputeExp(op1, sarray[0], op2);
                    }
                    if (!directSignals.Keys.Contains(key))
                        directSignals.Add(key, result);
                    outputString.Append(key + " : " + result + "\n");
                    DeleteKeys.Add(key);
                }
            }
            if (isFirstitteration)
                signalsTodecoded.Add(key, Value);
        }

        public int ComputeExp(int op1, string bop, int op2)
        {
            int result = 0;
            switch (bop)
            {
                case "AND":
                    result = op1 & op2;
                    break;
                case "OR":
                    result = op1 | op2;
                    break;
                case "RSHIFT":
                    result = op1 >> op2;
                    break;
                case "LSHIFT":
                    result = op1 << op2;
                    break;
                case "NOT":
                    result = ~op2;
                    break;
                default:
                    break;
            }
            return result;
        }
    }
}
