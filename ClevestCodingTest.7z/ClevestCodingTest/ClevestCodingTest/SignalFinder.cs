﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ClevestCodingTest
{
    class SignalFinder
    {

        public void GetSignalDetails()
        {
            Console.WriteLine("Please enter the file path \n");
            string filePath = Console.ReadLine();
            string[] Instructions = System.IO.File.ReadAllLines(filePath);

            Dictionary<string, int> directSignals = new Dictionary<string, int>();
            Dictionary<string, string> signalsTodecoded = new Dictionary<string, string>();
            Dictionary<string, string> Operators = new Dictionary<string, string>() {
                { "AND", "&" },
                { "OR", "||" },
                { "NOT", "~" },
                { "LSHIFT", "<<" },
                { "RSHIFT", ">>" }
            };


            foreach (string Instruction in Instructions)
            {
                string key = Instruction.Split(new string[] { "->" }, StringSplitOptions.None)[1].Trim();
                string Value = Instruction.Split(new string[] { "->" }, StringSplitOptions.None)[0].Trim();
                if (Value.All(Char.IsDigit))
                {
                    directSignals.Add(key, Convert.ToInt32(Value));
                }
                else
                {
                    Value.Split(' ');
                    bool flag = true;
                    string[] sarray = Value.Split(' ');
                    for (int i = 0; i <= sarray.Length - 1; i++)
                    {
                        if (!(Operators.Keys.Contains(sarray[i]) || directSignals.Keys.Contains(sarray[i]) || sarray[i].All(char.IsDigit)))
                        {
                            flag = false;
                            break;
                        }
                        else
                        {
                            if (directSignals.Keys.Contains(sarray[i]))
                            {
                                sarray[Array.IndexOf(sarray, sarray[i])] = directSignals[sarray[i]].ToString();
                            }
                            else if (Operators.Keys.Contains(sarray[i]))
                            {
                                sarray[Array.IndexOf(sarray, sarray[i])] = Operators[sarray[i]].ToString();
                            }
                        }
                        if (i == sarray.Length - 1 && flag == true)
                        {
                            
                        }
                    }
                        signalsTodecoded.Add(key, Value);
                }
                // Signals.Add(Instruction.Split(new string[] { " -> " }, StringSplitOptions.None)[0], Instruction.Split(new string[] { " -> " }, StringSplitOptions.None)[1]);
            }
        }
    }
}
