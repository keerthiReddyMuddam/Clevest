﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClevestCodingTest
{
    class HousesVisitCounter
    {
        public int VisitCount()
        {
            long verticalPosition = 0, horizontalPosition = 0;
            string Instructions = "";
            bool isValidinput = true;

            Console.WriteLine("Please enter the file path \n");
            string filePath = Console.ReadLine();
           
            HashSet<string> houseLocation = new HashSet<string>() { "(0,0)"};
            try
            {
                Instructions = System.IO.File.ReadAllText(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception" + ex.Message);
            }
            for (int i = 0; i < Instructions.Length; i++)
            {
                char direction = Instructions[i];
                switch (direction)
                {
                    case '>':
                        horizontalPosition++;
                        break;
                    case '<':
                        horizontalPosition--;
                        break;
                    case '^':
                        verticalPosition++;
                        break;
                    case 'v':
                        verticalPosition--;
                        break;
                    default:
                        Console.WriteLine("Invalid Input");
                        isValidinput = false;
                        break;
                }
                if (!isValidinput)
                    break;
                else
                houseLocation.Add("(" + horizontalPosition.ToString() + "," + verticalPosition.ToString() + ")");    
            }
            
            return houseLocation.Count;
        }
    }
}
