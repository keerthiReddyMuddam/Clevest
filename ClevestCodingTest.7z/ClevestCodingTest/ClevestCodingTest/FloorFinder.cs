﻿using System;

namespace ClevestCodingTest
{
    class FloorFinder
    {
        public long GetFloorDetails()
        {
            bool Retry = true,invalidInput=false;
            long floorNumber = 0;
            string wantToretry="";
            while (Retry)
            {
                Console.WriteLine("Please enter the file path \n");
                string FilePath = Console.ReadLine();
                string Instructions = "";
                try
                {
                    Instructions = System.IO.File.ReadAllText(@FilePath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Exception" + ex.Message);
                }
                for (int i = 0; i <= Instructions.Length - 1; i++)
                {
                    if (Instructions[i] == '(')
                        floorNumber++;
                    else if (Instructions[i] == ')')
                        floorNumber--;
                    else
                    {
                        invalidInput = true;
                        Console.WriteLine("Invalid Input ! Do you want to retry ? (Y/N)");
                        wantToretry = Console.ReadLine();
                        //exits the execution for any value other than Y
                        break;
                    }
                }
                if (invalidInput)
                    Retry = (wantToretry.Equals("Y")) ? true : false;
                else
                    Retry = false;

            }
            return floorNumber;
        }
    }
}
