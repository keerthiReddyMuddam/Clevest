﻿using System;
using System.Collections.Generic;

namespace ClevestCodingTest
{
    class StringValidator
    {
        public string IsGoodOrBadString()
        {
            int vowelCount = 0, Length = 0;
            bool hasConsecutiveletters = false, isGoodstring = true;
            string Result = "", inputString = "";
            Console.WriteLine("Please enter the file path :");
            string filePath = Console.ReadLine();
            try
            {
                inputString = System.IO.File.ReadAllText(filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception" + ex.Message);
            }
            //Hashsets for storing the values
            HashSet<char> Vowels = new HashSet<char> { 'a', 'e', 'i', 'o', 'u' };
            HashSet<string> badstring = new HashSet<string> { "ab", "cd", "pq", "xy" };

            Length = inputString.Length;
            for (int i = 0; i <= Length - 1; i++)
            {
                if (i <= Length - 2)
                {
                    if (badstring.Contains(inputString.Substring(i, 2)))
                    {
                        isGoodstring = false;
                        break;
                    }
                    else if (!hasConsecutiveletters)
                    {
                        if (inputString[i] == inputString[i + 1])
                            hasConsecutiveletters = true;
                    }
                }

                if (vowelCount < 3 && Vowels.Contains(inputString[i]))
                {
                    vowelCount++;
                }
            }
            if (hasConsecutiveletters && vowelCount >= 3 && isGoodstring)
                Result = "Its a Good string";
            else
            {
                Result = "Its a bad string";
                if (!isGoodstring)
                    Result = Result + " as it contains some substring which is not allowed(ab,cd,pq,xy)";
                if (vowelCount < 3)
                    Result = Result + "as it must contain a minimum of 3 vowels \n";
                if (!hasConsecutiveletters)
                    Result = Result + "as it must contain atleast 1 consecutive repeated letter ";
            }

            return Result;
        }

    }
}
