﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ClevestCodingTest
{
    class Program
    {
        static void Main(string[] args)
        {
            string Retry = "Y";

            int Choice;

            //Console.WriteLine("Please enter the operation you want to perform");
            while (Retry == "Y")
            {
                Console.WriteLine("Please Enter the choice of puzzle you want to execute \n");
                Console.WriteLine("1 to get the floor from Instructions");
                Console.WriteLine("2 to find the number of houses read by the meter atleast once");
                Console.WriteLine("3 to validate the Input for Good or Bad string");
                Console.WriteLine("4 signalling information \n");
                Console.WriteLine("Choice :");

                int.TryParse(Console.ReadLine(), out Choice);
                switch (Choice)
                {
                    case 1:
                        FloorFinder FI = new FloorFinder();                    
                        Console.WriteLine("Floor Number :" + FI.GetFloorDetails().ToString());
                        break;
                    case 2:
                        HousesVisitCounter Hv = new HousesVisitCounter();
                        Console.WriteLine(Hv.VisitCount().ToString());
                        break;
                    case 3:
                        StringValidator Gb = new StringValidator();
                        Console.WriteLine(Gb.IsGoodOrBadString());
                        break;
                    case 4:
                        SignalFinder Sf = new SignalFinder();
                        Sf.GetSignalDetails();
                        break;
                    default:
                        Console.WriteLine("Wrong Selection");
                        break;
                }
                
                Console.WriteLine("Do you want to execute another puzzle ? (Y/N)");
                Retry = Console.ReadLine().ToUpper();

            }
        }
    }
}
